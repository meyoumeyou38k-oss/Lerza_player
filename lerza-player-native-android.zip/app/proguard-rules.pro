# Proguard rules for FZ Player
