package com.fzplayer.media;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import androidx.media.app.NotificationCompat.MediaStyle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.channels.FileChannel;
import android.os.ParcelFileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int PERMISSION_REQUEST_CODE = 101;
    public static final int FILE_CHOOSER_REQUEST_CODE = 1002;
    private static final String MEDIA_CHANNEL_ID = "lerza_player_media_channel";
    private static final int MEDIA_NOTIFICATION_ID = 1001;

    private MediaSessionCompat mediaSession;
    private long currentDurationSec = 0;
    private long currentPositionSec = 0;
    private boolean currentIsPlaying = false;
    private String currentTrackTitle = "Lerza Player";
    private String currentTrackArtist = "Music Player";
    private String currentTrackAlbum = "Lerza";

    private ValueCallback<Uri[]> mUploadCallback;
    private long lastBackPressTime = 0;

    // Background observers for automatic storage synchronization
    private ContentObserver videoStoreObserver;
    private ContentObserver audioStoreObserver;

    // Cache file paths and metadata for quick, reliable streaming and thumbnail extraction
    private final Map<Long, String> audioPathMap = new HashMap<>();
    private final Map<Long, String> videoPathMap = new HashMap<>();
    private final Map<Long, Long> audioSizeMap = new HashMap<>();
    private final Map<Long, Long> videoSizeMap = new HashMap<>();
    private final Map<Long, String> videoMimeMap = new HashMap<>();
    private final Map<Long, String> audioMimeMap = new HashMap<>();

    // In-memory LRU Caches for album covers and video thumbnails (prevents OOM & WebView crashes)
    private final LruCache<Long, byte[]> mArtCache = new LruCache<Long, byte[]>(6 * 1024 * 1024) {
        @Override
        protected int sizeOf(Long key, byte[] value) {
            return value != null ? value.length : 0;
        }
    };
    private final LruCache<Long, byte[]> mThumbCache = new LruCache<Long, byte[]>(6 * 1024 * 1024) {
        @Override
        protected int sizeOf(Long key, byte[] value) {
            return value != null ? value.length : 0;
        }
    };
    private int renderGoneReloadAttempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(0xFF090A10);
            getWindow().setNavigationBarColor(0xFF090A10);
        }

        createNotificationChannel();
        initMediaSession();

        webView = new WebView(this);
        setContentView(webView);

        // Modern WebViewAssetLoader securely serves local assets on https://appassets.androidplatform.net
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/res/", new WebViewAssetLoader.ResourcesPathHandler(this))
                .build();

        setupWebView(assetLoader);

        // Hierarchical Back Navigation using OnBackPressedDispatcher (Android 13+ compliant)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                dispatchHierarchicalBackPress();
            }
        });

        checkAndRequestPermissions();

        // Load app entry point
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void initMediaSession() {
        try {
            mediaSession = new MediaSessionCompat(this, "LerzaPlayerMediaSession");
            mediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    triggerJsAction("play");
                }

                @Override
                public void onPause() {
                    triggerJsAction("pause");
                }

                @Override
                public void onSkipToNext() {
                    triggerJsAction("next");
                }

                @Override
                public void onSkipToPrevious() {
                    triggerJsAction("prev");
                }

                @Override
                public void onSeekTo(long pos) {
                    triggerJsAction("seek", pos / 1000.0);
                }
            });
            mediaSession.setActive(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleActionIntent(intent);
    }

    private void handleActionIntent(Intent intent) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if ("ACTION_PREV".equals(action)) {
                triggerJsAction("prev");
            } else if ("ACTION_PLAY_PAUSE".equals(action)) {
                triggerJsAction("playPause");
            } else if ("ACTION_NEXT".equals(action)) {
                triggerJsAction("next");
            }
        }
    }

    public void triggerJsAction(String action, Object... args) {
        runOnUiThread(() -> {
            if (webView != null) {
                if (args.length > 0) {
                    webView.evaluateJavascript("if(window.handleNotificationAction) window.handleNotificationAction('" + action + "', " + args[0] + ");", null);
                } else {
                    webView.evaluateJavascript("if(window.handleNotificationAction) window.handleNotificationAction('" + action + "');", null);
                }
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    MEDIA_CHANNEL_ID,
                    "Lerza Player Media Playback",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows active playback controls and track information");
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public void showMediaNotification(String title, String artist, String album, boolean isPlaying) {
        showMediaNotification(title, artist, album, isPlaying, null, null);
    }

    /**
     * Shows a persistent Android MediaStyle playback notification with seek bar, controls, and track album art
     */
    public void showMediaNotification(String title, String artist, String album, boolean isPlaying, String artworkUrl, String trackId) {
        try {
            this.currentIsPlaying = isPlaying;
            if (title != null && !title.trim().isEmpty()) this.currentTrackTitle = title;
            if (artist != null && !artist.trim().isEmpty()) this.currentTrackArtist = artist;
            if (album != null && !album.trim().isEmpty()) this.currentTrackAlbum = album;

            Intent openIntent = new Intent(this, MainActivity.class);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int pendingFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                    : PendingIntent.FLAG_UPDATE_CURRENT;

            PendingIntent pendingOpen = PendingIntent.getActivity(this, 0, openIntent, pendingFlags);

            // Previous Action Intent
            Intent prevIntent = new Intent(this, MainActivity.class).setAction("ACTION_PREV");
            PendingIntent pendingPrev = PendingIntent.getActivity(this, 1, prevIntent, pendingFlags);

            // Play/Pause Action Intent
            Intent playPauseIntent = new Intent(this, MainActivity.class).setAction("ACTION_PLAY_PAUSE");
            PendingIntent pendingPlayPause = PendingIntent.getActivity(this, 2, playPauseIntent, pendingFlags);

            // Next Action Intent
            Intent nextIntent = new Intent(this, MainActivity.class).setAction("ACTION_NEXT");
            PendingIntent pendingNext = PendingIntent.getActivity(this, 3, nextIntent, pendingFlags);

            String trackTitle = (this.currentTrackTitle != null && !this.currentTrackTitle.trim().isEmpty()) ? this.currentTrackTitle : "Lerza Player";
            String subText = (this.currentTrackArtist != null && !this.currentTrackArtist.trim().isEmpty()) ? this.currentTrackArtist : "Music Player";
            if (this.currentTrackAlbum != null && !this.currentTrackAlbum.trim().isEmpty() && !this.currentTrackAlbum.equalsIgnoreCase("Device Storage")) {
                subText += " • " + this.currentTrackAlbum;
            }

            // Extract album art / thumbnail for notification
            Bitmap artBitmap = null;
            try {
                if (trackId != null && trackId.startsWith("android-media-")) {
                    long audioId = Long.parseLong(trackId.replace("android-media-", ""));
                    byte[] artBytes = extractEmbeddedArt(audioId);
                    if (artBytes != null && artBytes.length > 0) {
                        artBitmap = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                    }
                } else if (trackId != null && trackId.startsWith("android-video-")) {
                    long videoId = Long.parseLong(trackId.replace("android-video-", ""));
                    byte[] thumbBytes = extractVideoThumbnail(videoId);
                    if (thumbBytes != null && thumbBytes.length > 0) {
                        artBitmap = BitmapFactory.decodeByteArray(thumbBytes, 0, thumbBytes.length);
                    }
                }
            } catch (Exception ignored) {}

            // Sync MediaSession playback state with seek position for interactive lock screen scrubber
            if (mediaSession != null) {
                long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE |
                        PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                        PlaybackStateCompat.ACTION_SEEK_TO;
                int state = isPlaying ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
                mediaSession.setPlaybackState(new PlaybackStateCompat.Builder()
                        .setActions(actions)
                        .setState(state, currentPositionSec * 1000, 1.0f)
                        .build());

                MediaMetadataCompat.Builder metaBuilder = new MediaMetadataCompat.Builder()
                        .putString(MediaMetadataCompat.METADATA_KEY_TITLE, trackTitle)
                        .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, subText)
                        .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, Math.max(1, currentDurationSec) * 1000);

                if (artBitmap != null) {
                    metaBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, artBitmap);
                    metaBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, artBitmap);
                }

                mediaSession.setMetadata(metaBuilder.build());
            }

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, MEDIA_CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(trackTitle)
                    .setContentText(subText)
                    .setContentIntent(pendingOpen)
                    .setOngoing(isPlaying)
                    .setOnlyAlertOnce(true)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .addAction(android.R.drawable.ic_media_previous, "Previous", pendingPrev)
                    .addAction(isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                            isPlaying ? "Pause" : "Play", pendingPlayPause)
                    .addAction(android.R.drawable.ic_media_next, "Next", pendingNext);

            if (artBitmap != null) {
                builder.setLargeIcon(artBitmap);
            }

            if (mediaSession != null) {
                builder.setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
            }

            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.notify(MEDIA_NOTIFICATION_ID, builder.build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Registers background MediaStore content observers so newly downloaded
     * or added videos and audio files immediately populate their respective tabs.
     */
    private void registerMediaStoreObservers() {
        if (videoStoreObserver == null) {
            videoStoreObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
                @Override
                public void onChange(boolean selfChange, Uri uri) {
                    super.onChange(selfChange, uri);
                    scanLocalVideoFiles();
                }
            };
            try {
                getContentResolver().registerContentObserver(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        true,
                        videoStoreObserver
                );
            } catch (Exception ignored) {}
        }

        if (audioStoreObserver == null) {
            audioStoreObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
                @Override
                public void onChange(boolean selfChange, Uri uri) {
                    super.onChange(selfChange, uri);
                    scanLocalAudioFiles();
                }
            };
            try {
                getContentResolver().registerContentObserver(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        true,
                        audioStoreObserver
                );
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaSession != null) {
            try {
                mediaSession.setActive(false);
                mediaSession.release();
            } catch (Exception ignored) {}
            mediaSession = null;
        }
        if (videoStoreObserver != null) {
            try { getContentResolver().unregisterContentObserver(videoStoreObserver); } catch (Exception ignored) {}
            videoStoreObserver = null;
        }
        if (audioStoreObserver != null) {
            try { getContentResolver().unregisterContentObserver(audioStoreObserver); } catch (Exception ignored) {}
            audioStoreObserver = null;
        }
    }

    private void setupWebView(final WebViewAssetLoader assetLoader) {
        // Enforce full GPU hardware acceleration for smooth 60/120fps mobile rendering
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        WebView.setWebContentsDebuggingEnabled(true);

        // Native Android Bridge to trigger scanning from Web UI
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void scanLocalAudio() {
                scanLocalAudioFiles();
            }

            @JavascriptInterface
            public void scanLocalVideos() {
                scanLocalVideoFiles();
            }

            @JavascriptInterface
            public void minimizeApp() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        moveTaskToBack(true);
                    }
                });
            }

            @JavascriptInterface
            public boolean isAndroid() {
                return true;
            }

            @JavascriptInterface
            public void updateSeekPosition(final int currentSec, final int totalSec) {
                currentPositionSec = currentSec;
                currentDurationSec = totalSec;
                if (mediaSession != null) {
                    long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE |
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                            PlaybackStateCompat.ACTION_SEEK_TO;
                    int state = currentIsPlaying ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
                    mediaSession.setPlaybackState(new PlaybackStateCompat.Builder()
                            .setActions(actions)
                            .setState(state, currentPositionSec * 1000, 1.0f)
                            .build());
                }
            }

            @JavascriptInterface
            public void updateNotification(final String title, final String artist, final String album, final boolean isPlaying) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showMediaNotification(title, artist, album, isPlaying);
                    }
                });
            }

            @JavascriptInterface
            public void updateNotificationWithArt(final String title, final String artist, final String album, final boolean isPlaying, final String artworkUrl, final String trackId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showMediaNotification(title, artist, album, isPlaying, artworkUrl, trackId);
                    }
                });
            }

            @JavascriptInterface
            public void setScreenOrientation(final String orientation) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if ("landscape".equalsIgnoreCase(orientation)) {
                                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                            } else if ("portrait".equalsIgnoreCase(orientation)) {
                                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                            } else {
                                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                            }
                        } catch (Exception ignored) {}
                    }
                });
            }

            @JavascriptInterface
            public void toggleFullscreen(final boolean fullscreen) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (fullscreen) {
                                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                    WindowInsetsController controller = getWindow().getInsetsController();
                                    if (controller != null) {
                                        controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                                        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                                    }
                                }
                                getWindow().getDecorView().setSystemUiVisibility(
                                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                );
                            } else {
                                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                    WindowInsetsController controller = getWindow().getInsetsController();
                                    if (controller != null) {
                                        controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                                    }
                                }
                                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                            }
                        } catch (Exception ignored) {}
                    }
                });
            }

            @JavascriptInterface
            public void fetchRemoteUpdateJson(final String urlString) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = new URL(urlString);
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("GET");
                            conn.setConnectTimeout(8000);
                            conn.setReadTimeout(8000);
                            conn.setRequestProperty("Accept", "application/json");
                            conn.setRequestProperty("User-Agent", "LerzaPlayer-Android");
                            int responseCode = conn.getResponseCode();
                            if (responseCode == 200) {
                                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                                StringBuilder sb = new StringBuilder();
                                String line;
                                while ((line = in.readLine()) != null) {
                                    sb.append(line);
                                }
                                in.close();
                                final String jsonStr = sb.toString();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        webView.evaluateJavascript("window.onAndroidUpdateJsonReceived && window.onAndroidUpdateJsonReceived(" + JSONObject.quote(jsonStr) + ");", null);
                                    }
                                });
                            } else {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        webView.evaluateJavascript("window.onAndroidUpdateJsonFailed && window.onAndroidUpdateJsonFailed('HTTP " + responseCode + "');", null);
                                    }
                                });
                            }
                        } catch (final Exception e) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    webView.evaluateJavascript("window.onAndroidUpdateJsonFailed && window.onAndroidUpdateJsonFailed('" + e.getMessage() + "');", null);
                                }
                            });
                        }
                    }
                }).start();
            }
        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (uri.getHost() != null && uri.getHost().contains("appassets.androidplatform.net")) {
                        return false;
                    }
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }

            private WebResourceResponse handleMediaStream(WebResourceRequest request, Uri contentUri, boolean isAudio, long mediaId) {
                try {
                    String filePath = isAudio ? audioPathMap.get(mediaId) : videoPathMap.get(mediaId);
                    if ((filePath == null || filePath.isEmpty()) && contentUri != null && "file".equalsIgnoreCase(contentUri.getScheme())) {
                        filePath = contentUri.getPath();
                    }

                    // 1. Determine totalLength and seekable channel
                    ParcelFileDescriptor pfd = null;
                    File file = null;

                    if (contentUri != null && !"file".equalsIgnoreCase(contentUri.getScheme())) {
                        try {
                            pfd = getContentResolver().openFileDescriptor(contentUri, "r");
                        } catch (Exception ignored) {}
                    }

                    if (pfd == null && filePath != null && !filePath.isEmpty()) {
                        File f = new File(filePath);
                        if (f.exists() && f.canRead()) {
                            file = f;
                        }
                    }

                    long totalLength = -1;
                    if (pfd != null) {
                        try {
                            totalLength = pfd.getStatSize();
                        } catch (Exception ignored) {}
                    } else if (file != null) {
                        totalLength = file.length();
                    }

                    // Fallback to cached size from MediaStore query
                    if (totalLength <= 0 && mediaId > 0) {
                        Long cachedSize = isAudio ? audioSizeMap.get(mediaId) : videoSizeMap.get(mediaId);
                        if (cachedSize != null && cachedSize > 0) {
                            totalLength = cachedSize;
                        }
                    }

                    // Fallback to File check if pfd stat size was 0
                    if (totalLength <= 0 && filePath != null && !filePath.isEmpty()) {
                        try {
                            File f = new File(filePath);
                            if (f.exists()) totalLength = f.length();
                        } catch (Exception ignored) {}
                    }

                    // 2. MIME type resolution - check extension first if path is available
                    String mimeType = null;
                    String testPath = filePath;
                    if ((testPath == null || testPath.isEmpty()) && contentUri != null) {
                        testPath = contentUri.getLastPathSegment();
                    }
                    if (testPath != null && !testPath.isEmpty()) {
                        int dot = testPath.lastIndexOf('.');
                        if (dot >= 0) {
                            String ext = testPath.substring(dot + 1).toLowerCase();
                            if ("m4a".equals(ext)) mimeType = "audio/mp4";
                            else if ("aac".equals(ext)) mimeType = "audio/aac";
                            else if ("mp3".equals(ext)) mimeType = "audio/mpeg";
                            else if ("flac".equals(ext)) mimeType = "audio/flac";
                            else if ("wav".equals(ext)) mimeType = "audio/wav";
                            else if ("ogg".equals(ext) || "oga".equals(ext)) mimeType = "audio/ogg";
                            else if ("opus".equals(ext)) mimeType = "audio/opus";
                            else if ("wma".equals(ext)) mimeType = "audio/x-ms-wma";
                            else if ("amr".equals(ext)) mimeType = "audio/amr";
                            else if ("3ga".equals(ext)) mimeType = "audio/3gpp";
                            else if ("3gp".equals(ext)) mimeType = isAudio ? "audio/3gpp" : "video/3gpp";
                            else if ("mkv".equals(ext)) mimeType = "video/x-matroska";
                            else if ("webm".equals(ext)) mimeType = isAudio ? "audio/webm" : "video/webm";
                            else if ("mov".equals(ext)) mimeType = "video/quicktime";
                            else if ("mp4".equals(ext) || "m4v".equals(ext)) mimeType = "video/mp4";
                            else if ("avi".equals(ext)) mimeType = "video/x-msvideo";
                            else if ("flv".equals(ext)) mimeType = "video/x-flv";
                            else if ("ts".equals(ext)) mimeType = "video/mp2t";
                            else if ("wmv".equals(ext)) mimeType = "video/x-ms-wmv";
                            else {
                                mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                            }
                        }
                    }

                    if (mimeType == null || mimeType.isEmpty() || "application/octet-stream".equalsIgnoreCase(mimeType)) {
                        mimeType = isAudio ? audioMimeMap.get(mediaId) : videoMimeMap.get(mediaId);
                    }

                    if (mimeType == null || mimeType.isEmpty() || "application/octet-stream".equalsIgnoreCase(mimeType)) {
                        if (contentUri != null) {
                            try {
                                mimeType = getContentResolver().getType(contentUri);
                            } catch (Exception ignored) {}
                        }
                    }

                    if (mimeType == null || mimeType.isEmpty()) {
                        mimeType = isAudio ? "audio/mpeg" : "video/mp4";
                    }

                    // Strict normalization for Chromium player:
                    // 1. M4A / AAC audio MUST be served as audio/mp4 for Chromium HTML5 audio
                    // 2. QuickTime / Snapchat / HEVC video normalized to video/mp4 with full range support
                    if (isAudio) {
                        String lower = mimeType.toLowerCase();
                        if (lower.contains("m4a") || lower.contains("mp4a") || lower.contains("aac") || lower.contains("audio/mp4")) {
                            mimeType = "audio/mp4";
                        }
                    } else {
                        String lower = mimeType.toLowerCase();
                        if (lower.contains("quicktime") || lower.contains("snapchat") || lower.contains("m4v") || lower.contains("hevc") || lower.contains("h265")) {
                            mimeType = "video/mp4";
                        }
                    }

                    // 3. Read Range header (Handles standard bytes=X-Y, open-ended bytes=X-, and critical suffix bytes=-N)
                    String rangeHeader = null;
                    Map<String, String> reqHeaders = request.getRequestHeaders();
                    if (reqHeaders != null) {
                        for (Map.Entry<String, String> e : reqHeaders.entrySet()) {
                            if ("range".equalsIgnoreCase(e.getKey())) {
                                rangeHeader = e.getValue();
                                break;
                            }
                        }
                    }

                    long start = 0;
                    long end = (totalLength > 0) ? (totalLength - 1) : -1;
                    boolean isRangeRequest = false;

                    if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
                        isRangeRequest = true;
                        String rangeVal = rangeHeader.substring(6).trim();
                        if (rangeVal.startsWith("-")) {
                            // Suffix Range Request (e.g., bytes=-32768)
                            // Chromium requests this to locate the 'moov atom' at the END of Snapchat videos & M4A audios!
                            try {
                                long suffix = Long.parseLong(rangeVal.substring(1).trim());
                                if (totalLength > 0) {
                                    start = Math.max(0, totalLength - suffix);
                                    end = totalLength - 1;
                                }
                            } catch (Exception ignored) {}
                        } else {
                            int dashPos = rangeVal.indexOf('-');
                            if (dashPos >= 0) {
                                String startPart = rangeVal.substring(0, dashPos).trim();
                                String endPart = rangeVal.substring(dashPos + 1).trim();
                                if (!startPart.isEmpty()) {
                                    try { start = Long.parseLong(startPart); } catch (Exception ignored) {}
                                }
                                if (!endPart.isEmpty()) {
                                    try { end = Long.parseLong(endPart); } catch (Exception ignored) {}
                                }
                            } else {
                                try { start = Long.parseLong(rangeVal); } catch (Exception ignored) {}
                            }
                        }
                        if (end < start && totalLength > 0) {
                            end = totalLength - 1;
                        }
                    }

                    if (end < 0 && totalLength > 0) {
                        end = totalLength - 1;
                    }

                    // 4. Create seekable InputStream with robust position channel
                    InputStream rawStream = null;
                    final ParcelFileDescriptor activePfd = pfd;

                    if (pfd != null) {
                        FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
                        if (start > 0) {
                            try {
                                fis.getChannel().position(start);
                            } catch (Exception e) {
                                long skipped = 0;
                                while (skipped < start) {
                                    long s = fis.skip(start - skipped);
                                    if (s <= 0) break;
                                    skipped += s;
                                }
                            }
                        }
                        rawStream = fis;
                    } else if (file != null) {
                        FileInputStream fis = new FileInputStream(file);
                        if (start > 0) {
                            try {
                                fis.getChannel().position(start);
                            } catch (Exception e) {
                                long skipped = 0;
                                while (skipped < start) {
                                    long s = fis.skip(start - skipped);
                                    if (s <= 0) break;
                                    skipped += s;
                                }
                            }
                        }
                        rawStream = fis;
                    } else if (contentUri != null) {
                        try {
                            ParcelFileDescriptor retryPfd = getContentResolver().openFileDescriptor(contentUri, "r");
                            if (retryPfd != null) {
                                FileInputStream fis = new FileInputStream(retryPfd.getFileDescriptor());
                                if (start > 0) {
                                    try {
                                        fis.getChannel().position(start);
                                    } catch (Exception ignored) {}
                                }
                                rawStream = fis;
                            }
                        } catch (Exception ignored) {}

                        if (rawStream == null) {
                            InputStream cis = getContentResolver().openInputStream(contentUri);
                            if (cis != null && start > 0) {
                                long skipped = 0;
                                while (skipped < start) {
                                    long s = cis.skip(start - skipped);
                                    if (s <= 0) break;
                                    skipped += s;
                                }
                            }
                            rawStream = cis;
                        }
                    }

                    if (rawStream == null) {
                        if (activePfd != null) {
                            try { activePfd.close(); } catch (Exception ignored) {}
                        }
                        return null;
                    }

                    // Auto-closing wrapper that ensures PFD is released cleanly
                    InputStream closableStream = new FilterInputStream(rawStream) {
                        @Override
                        public void close() throws IOException {
                            try {
                                super.close();
                            } finally {
                                if (activePfd != null) {
                                    try { activePfd.close(); } catch (Exception ignored) {}
                                }
                            }
                        }
                    };

                    // If range bounds are known, limit stream to contentLength bytes
                    final long contentLength = (end >= start && totalLength > 0)
                        ? (end - start + 1)
                        : (totalLength > 0 ? (totalLength - start) : -1);

                    InputStream boundedStream = closableStream;
                    if (contentLength > 0) {
                        final long maxBytes = contentLength;
                        boundedStream = new FilterInputStream(closableStream) {
                            private long remaining = maxBytes;
                            @Override
                            public int read() throws IOException {
                                if (remaining <= 0) return -1;
                                int b = super.read();
                                if (b != -1) remaining--;
                                return b;
                            }
                            @Override
                            public int read(byte[] b, int off, int len) throws IOException {
                                if (remaining <= 0) return -1;
                                int toRead = (int) Math.min(len, remaining);
                                int r = super.read(b, off, toRead);
                                if (r != -1) remaining -= r;
                                return r;
                            }
                            @Override
                            public int available() throws IOException {
                                return (int) Math.min(super.available(), Math.max(0, remaining));
                            }
                        };
                    }

                    Map<String, String> respHeaders = new HashMap<>();
                    respHeaders.put("Accept-Ranges", "bytes");
                    respHeaders.put("Access-Control-Allow-Origin", "*");
                    respHeaders.put("Cache-Control", "no-cache");

                    if (isRangeRequest && totalLength > 0) {
                        String contentRange = "bytes " + start + "-" + end + "/" + totalLength;
                        respHeaders.put("Content-Range", contentRange);
                        if (contentLength > 0) {
                            respHeaders.put("Content-Length", String.valueOf(contentLength));
                        }
                        return new WebResourceResponse(mimeType, null, 206, "Partial Content", respHeaders, boundedStream);
                    } else {
                        if (totalLength > 0) {
                            respHeaders.put("Content-Length", String.valueOf(totalLength));
                        }
                        return new WebResourceResponse(mimeType, null, 200, "OK", respHeaders, boundedStream);
                    }
                } catch (Exception e) {
                    try {
                        InputStream is = getContentResolver().openInputStream(contentUri);
                        if (is != null) {
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Accept-Ranges", "bytes");
                            headers.put("Access-Control-Allow-Origin", "*");
                            return new WebResourceResponse(isAudio ? "audio/mpeg" : "video/mp4", null, 200, "OK", headers, is);
                        }
                    } catch (Exception ignored) {}
                }
                return null;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                String host = url.getHost();

                // If this is an external HTTP/HTTPS request (e.g., https://lerzaplayer.vercel.app or any external internet host),
                // do NOT intercept! Allow the native Chromium network stack to perform the real network request.
                if (host != null && !host.contains("appassets.androidplatform.net") && !host.contains("localhost") && !host.equals("127.0.0.1")) {
                    return null;
                }

                String path = url.getPath();

                if (path != null) {
                    // 1. Intercept direct local audio playback with byte-range seek and MIME detection
                    if (path.startsWith("/local-audio/") || path.contains("local-audio/")) {
                        try {
                            String idStr = path.substring(path.lastIndexOf('/') + 1);
                            long id = Long.parseLong(idStr);
                            Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                            return handleMediaStream(request, contentUri, true, id);
                        } catch (Exception ignored) {}
                    }

                    // 2. Intercept direct local video playback with byte-range seek and MIME detection
                    if (path.startsWith("/local-video/") || path.contains("local-video/")) {
                        try {
                            String idStr = path.substring(path.lastIndexOf('/') + 1);
                            long id = Long.parseLong(idStr);
                            Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                            return handleMediaStream(request, contentUri, false, id);
                        } catch (Exception ignored) {}
                    }

                    // 2.5 Intercept direct filesystem paths (/storage/..., /sdcard/..., /local-file/...)
                    if (path.startsWith("/storage/") || path.startsWith("/sdcard/") || path.startsWith("/local-file/")) {
                        try {
                            String targetPath = path.startsWith("/local-file/") ? path.substring("/local-file/".length()) : path;
                            targetPath = java.net.URLDecoder.decode(targetPath, "UTF-8");
                            if (!targetPath.startsWith("/")) targetPath = "/" + targetPath;
                            File targetFile = new File(targetPath);
                            if (targetFile.exists() && targetFile.canRead()) {
                                Uri fileUri = Uri.fromFile(targetFile);
                                boolean isAudio = !targetPath.toLowerCase().matches(".*\\.(mp4|mkv|webm|mov|3gp|avi|flv|m4v|ts|wmv)$");
                                return handleMediaStream(request, fileUri, isAudio, 0);
                            }
                        } catch (Exception ignored) {}
                    }

                    // 3. Intercept local audio embedded album art
                    if (path.startsWith("/local-audio-art/") || path.contains("local-audio-art/")) {
                        try {
                            String idStr = path.substring(path.lastIndexOf('/') + 1);
                            long id = Long.parseLong(idStr);
                            byte[] artBytes = extractEmbeddedArt(id);
                            if (artBytes != null && artBytes.length > 0) {
                                Map<String, String> headers = new HashMap<>();
                                headers.put("Cache-Control", "public, max-age=604800");
                                return new WebResourceResponse("image/jpeg", "UTF-8", 200, "OK", headers, new ByteArrayInputStream(artBytes));
                            }
                        } catch (Exception ignored) {}
                    }

                    // 4. Intercept local video thumbnail
                    if (path.startsWith("/local-video-thumb/") || path.contains("local-video-thumb/")) {
                        try {
                            String idStr = path.substring(path.lastIndexOf('/') + 1);
                            long id = Long.parseLong(idStr);
                            byte[] thumbBytes = extractVideoThumbnail(id);
                            if (thumbBytes != null && thumbBytes.length > 0) {
                                Map<String, String> headers = new HashMap<>();
                                headers.put("Cache-Control", "public, max-age=604800");
                                return new WebResourceResponse("image/jpeg", "UTF-8", 200, "OK", headers, new ByteArrayInputStream(thumbBytes));
                            }
                        } catch (Exception ignored) {}
                    }
                }

                // 5. Delegate to WebViewAssetLoader
                WebResourceResponse response = assetLoader.shouldInterceptRequest(url);
                if (response != null) {
                    return response;
                }

                // 6. Custom fallback interceptor for all relative/absolute asset paths
                if (path != null) {
                    String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                    if (cleanPath.startsWith("assets/")) {
                        cleanPath = cleanPath.substring("assets/".length());
                    }

                    try {
                        InputStream is = getAssets().open(cleanPath);
                        String mimeType = getMimeType(cleanPath);
                        WebResourceResponse resp = new WebResourceResponse(mimeType, "UTF-8", is);
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        headers.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
                        headers.put("Access-Control-Allow-Headers", "*");
                        resp.setResponseHeaders(headers);
                        return resp;
                    } catch (Exception ignored) {
                        try {
                            InputStream is2 = getAssets().open("assets/" + cleanPath);
                            String mimeType = getMimeType(cleanPath);
                            WebResourceResponse resp2 = new WebResourceResponse(mimeType, "UTF-8", is2);
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Access-Control-Allow-Origin", "*");
                            headers.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
                            headers.put("Access-Control-Allow-Headers", "*");
                            resp2.setResponseHeaders(headers);
                            return resp2;
                        } catch (Exception ignored2) {}
                    }
                }

                return null;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Automatically scan and sync all device audio and video files as soon as app opens
                scanLocalAudioFiles();
                scanLocalVideoFiles();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net") && failingUrl.endsWith("index.html")) {
                    view.loadUrl("file:///android_asset/index.html");
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // Prevent app crash loop if WebView render process runs out of memory or terminates
                if (renderGoneReloadAttempts >= 2) {
                    return false; // Prevent infinite reload loop
                }
                renderGoneReloadAttempts++;
                if (view != null) {
                    ViewGroup parent = (ViewGroup) view.getParent();
                    if (parent != null) {
                        parent.removeView(view);
                    }
                    view.destroy();
                }
                // Re-create WebView safely
                webView = new WebView(MainActivity.this);
                setContentView(webView);
                setupWebView(assetLoader);
                webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
                return true;
            }
        });

        // WebChromeClient with onShowFileChooser for Gallery and File selection
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                request.grant(request.getResources());
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                if (mUploadCallback != null) {
                    mUploadCallback.onReceiveValue(null);
                    mUploadCallback = null;
                }
                mUploadCallback = filePathCallback;

                Intent intent = null;
                try {
                    intent = fileChooserParams.createIntent();
                    if (fileChooserParams.getAcceptTypes() != null && fileChooserParams.getAcceptTypes().length > 0) {
                        String mime = fileChooserParams.getAcceptTypes()[0];
                        if (mime != null && !mime.isEmpty()) {
                            intent.setType(mime);
                        }
                    }
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(Intent.createChooser(intent, "Select Picture or Media"), FILE_CHOOSER_REQUEST_CODE);
                    return true;
                } catch (Exception e) {
                    if (mUploadCallback != null) {
                        mUploadCallback.onReceiveValue(null);
                        mUploadCallback = null;
                    }
                    return false;
                }
            }
        });

        webView.setBackgroundColor(0xFF090A10);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (mUploadCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            mUploadCallback.onReceiveValue(results);
            mUploadCallback = null;
        }
    }

    /**
     * Extracts embedded ID3 album cover art from an audio file,
     * or checks the parent directory for cover.jpg / album.jpg.
     */
    private byte[] extractEmbeddedArt(long audioId) {
        byte[] cached = mArtCache.get(audioId);
        if (cached != null) {
            return cached;
        }

        String filePath = audioPathMap.get(audioId);

        // 1. MediaMetadataRetriever via MediaStore Content URI
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, audioId);
            retriever.setDataSource(this, contentUri);
            byte[] embedded = retriever.getEmbeddedPicture();
            if (embedded != null && embedded.length > 0) {
                mArtCache.put(audioId, embedded);
                return embedded;
            }
        } catch (Exception ignored) {
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }

        // 2. MediaMetadataRetriever directly on direct file path
        if (filePath != null && new File(filePath).exists()) {
            MediaMetadataRetriever fileRetriever = new MediaMetadataRetriever();
            try {
                fileRetriever.setDataSource(filePath);
                byte[] embedded = fileRetriever.getEmbeddedPicture();
                if (embedded != null && embedded.length > 0) {
                    mArtCache.put(audioId, embedded);
                    return embedded;
                }
            } catch (Exception ignored) {
            } finally {
                try { fileRetriever.release(); } catch (Exception ignored) {}
            }
        }

        // 3. Fallback: check file directory for cover.jpg / album.jpg / folder.jpg / artwork.jpg
        if (filePath != null) {
            try {
                File audioFile = new File(filePath);
                File dir = audioFile.getParentFile();
                if (dir != null && dir.isDirectory()) {
                    String[] candidates = {"cover.jpg", "album.jpg", "folder.jpg", "cover.png", "artwork.jpg", "front.jpg"};
                    for (String candidate : candidates) {
                        File imageFile = new File(dir, candidate);
                        if (imageFile.exists() && imageFile.isFile() && imageFile.length() > 0) {
                            FileInputStream fis = new FileInputStream(imageFile);
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            byte[] buffer = new byte[4096];
                            int read;
                            while ((read = fis.read(buffer)) != -1) {
                                bos.write(buffer, 0, read);
                            }
                            fis.close();
                            byte[] data = bos.toByteArray();
                            mArtCache.put(audioId, data);
                            return data;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }

        return null;
    }

    /**
     * Hardware-accelerated fast video thumbnail extraction.
     * Prioritizes OS pre-computed MediaStore thumbnail database (Android Q+ loadThumbnail or MiniKind)
     * which loads in 2-5ms instead of decoding entire video files.
     */
    private byte[] extractVideoThumbnail(long videoId) {
        byte[] cached = mThumbCache.get(videoId);
        if (cached != null) {
            return cached;
        }

        Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, videoId);

        // 1. Android 10+ (API 29+) Hardware-accelerated MediaStore thumbnail cache
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Bitmap thumb = getContentResolver().loadThumbnail(contentUri, new Size(320, 240), null);
                if (thumb != null) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    thumb.compress(Bitmap.CompressFormat.JPEG, 75, bos);
                    thumb.recycle();
                    byte[] data = bos.toByteArray();
                    mThumbCache.put(videoId, data);
                    return data;
                }
            } catch (Exception ignored) {}
        }

        // 2. Android 9 and lower: query pre-computed MediaStore thumbnail table
        try {
            Bitmap thumb = MediaStore.Video.Thumbnails.getThumbnail(
                    getContentResolver(),
                    videoId,
                    MediaStore.Video.Thumbnails.MINI_KIND,
                    null
            );
            if (thumb != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                thumb.compress(Bitmap.CompressFormat.JPEG, 75, bos);
                thumb.recycle();
                byte[] data = bos.toByteArray();
                mThumbCache.put(videoId, data);
                return data;
            }
        } catch (Exception ignored) {}

        // 3. Fallback: File path thumbnail extraction via ThumbnailUtils
        String filePath = videoPathMap.get(videoId);
        if (filePath != null) {
            try {
                Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Images.Thumbnails.MINI_KIND);
                if (bitmap != null) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 75, bos);
                    bitmap.recycle();
                    byte[] data = bos.toByteArray();
                    mThumbCache.put(videoId, data);
                    return data;
                }
            } catch (Exception ignored) {}
        }

        // 4. Fallback via MediaMetadataRetriever (scaled frame for speed)
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, contentUri);
            Bitmap frame = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                frame = retriever.getScaledFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 240);
            } else {
                frame = retriever.getFrameAtTime(1000000);
            }
            if (frame != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                frame.compress(Bitmap.CompressFormat.JPEG, 75, bos);
                frame.recycle();
                byte[] data = bos.toByteArray();
                mThumbCache.put(videoId, data);
                return data;
            }
        } catch (Exception ignored) {
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }

        return null;
    }

    /**
     * Scans all local downloaded audio files from phone storage via MediaStore
     * and passes them directly to the Web interface.
     */
    public void scanLocalAudioFiles() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final JSONArray jsonArray = new JSONArray();
                    ContentResolver resolver = getContentResolver();
                    Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    String selection = "(" + MediaStore.Audio.Media.IS_MUSIC + " != 0 OR " + MediaStore.Audio.Media.DURATION + " > 1000 OR " + 
                            MediaStore.Audio.Media.DATA + " LIKE '%.m4a' OR " +
                            MediaStore.Audio.Media.DATA + " LIKE '%.aac' OR " +
                            MediaStore.Audio.Media.DATA + " LIKE '%.mp3' OR " +
                            MediaStore.Audio.Media.DATA + " LIKE '%.flac' OR " +
                            MediaStore.Audio.Media.DATA + " LIKE '%.wav' OR " +
                            MediaStore.Audio.Media.DATA + " LIKE '%.ogg')";
                    String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";

                    String[] projection = {
                            MediaStore.Audio.Media._ID,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION,
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.SIZE,
                            MediaStore.Audio.Media.MIME_TYPE
                    };

                    Cursor cursor = resolver.query(uri, projection, selection, null, sortOrder);
                    if (cursor != null) {
                        int idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
                        int titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
                        int artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                        int albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                        int durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
                        int dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                        int sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE);
                        int mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE);

                        while (cursor.moveToNext()) {
                            long id = idCol != -1 ? cursor.getLong(idCol) : 0;
                            String title = titleCol != -1 ? cursor.getString(titleCol) : "";
                            String artist = artistCol != -1 ? cursor.getString(artistCol) : "";
                            String album = albumCol != -1 ? cursor.getString(albumCol) : "";
                            long durationMs = durationCol != -1 ? cursor.getLong(durationCol) : 0;
                            String data = dataCol != -1 ? cursor.getString(dataCol) : "";
                            long size = sizeCol != -1 ? cursor.getLong(sizeCol) : 0;
                            String mime = mimeCol != -1 ? cursor.getString(mimeCol) : "";

                            if (data != null && !data.isEmpty()) {
                                audioPathMap.put(id, data);
                            }
                            if (size > 0) {
                                audioSizeMap.put(id, size);
                            }
                            if (mime != null && !mime.isEmpty()) {
                                audioMimeMap.put(id, mime);
                            }

                            JSONObject obj = new JSONObject();
                            obj.put("id", "android-media-" + id);
                            obj.put("title", (title != null && !title.trim().isEmpty()) ? title : "Audio Track");
                            obj.put("artist", (artist != null && !artist.equals("<unknown>") && !artist.trim().isEmpty()) ? artist : "Device Storage");
                            obj.put("album", (album != null && !album.equals("<unknown>") && !album.trim().isEmpty()) ? album : "Local Music");
                            obj.put("duration", Math.max(1, (int)(durationMs / 1000)));
                            obj.put("audioUrl", "https://appassets.androidplatform.net/local-audio/" + id);
                            obj.put("filePath", data != null ? data : "");
                            obj.put("fileSize", String.format("%.1f MB", size / (1024.0 * 1024.0)));
                            String ext = "MP3";
                            if (data != null) {
                                int dotIdx = data.lastIndexOf('.');
                                if (dotIdx >= 0) {
                                    ext = data.substring(dotIdx + 1).toUpperCase();
                                }
                            }
                            obj.put("fileFormat", ext);
                            obj.put("hasMV", false);
                            obj.put("genre", "Local Music");
                            obj.put("isFavorite", false);
                            obj.put("playCount", 0);
                            obj.put("dateAdded", System.currentTimeMillis());
                            obj.put("folder", "Device Storage / Music");
                            obj.put("artworkUrl", "https://appassets.androidplatform.net/local-audio-art/" + id);

                            jsonArray.put(obj);
                        }
                        cursor.close();
                    }

                    final String payload = jsonArray.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            webView.evaluateJavascript("if (window.onAndroidLocalTracksScanned) { window.onAndroidLocalTracksScanned(" + payload + "); }", null);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * Recursively scans local video files from phone storage via MediaStore
     * including .mp4, .mkv, .webm, .avi, .3gp, .mov.
     */
    public void scanLocalVideoFiles() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final JSONArray jsonArray = new JSONArray();
                    ContentResolver resolver = getContentResolver();
                    Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    String sortOrder = MediaStore.Video.Media.DATE_ADDED + " DESC";

                    String[] projection = {
                            MediaStore.Video.Media._ID,
                            MediaStore.Video.Media.TITLE,
                            MediaStore.Video.Media.ARTIST,
                            MediaStore.Video.Media.ALBUM,
                            MediaStore.Video.Media.DURATION,
                            MediaStore.Video.Media.DATA,
                            MediaStore.Video.Media.SIZE,
                            MediaStore.Video.Media.MIME_TYPE
                    };

                    Cursor cursor = resolver.query(uri, projection, null, null, sortOrder);
                    if (cursor != null) {
                        int idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID);
                        int titleCol = cursor.getColumnIndex(MediaStore.Video.Media.TITLE);
                        int artistCol = cursor.getColumnIndex(MediaStore.Video.Media.ARTIST);
                        int albumCol = cursor.getColumnIndex(MediaStore.Video.Media.ALBUM);
                        int durationCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION);
                        int dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA);
                        int sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE);
                        int mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE);

                        while (cursor.moveToNext()) {
                            long id = idCol != -1 ? cursor.getLong(idCol) : 0;
                            String title = titleCol != -1 ? cursor.getString(titleCol) : "";
                            String artist = artistCol != -1 ? cursor.getString(artistCol) : "";
                            String album = albumCol != -1 ? cursor.getString(albumCol) : "";
                            long durationMs = durationCol != -1 ? cursor.getLong(durationCol) : 0;
                            String data = dataCol != -1 ? cursor.getString(dataCol) : "";
                            long size = sizeCol != -1 ? cursor.getLong(sizeCol) : 0;
                            String mime = mimeCol != -1 ? cursor.getString(mimeCol) : "";

                            if (data != null && !data.isEmpty()) {
                                videoPathMap.put(id, data);
                            }
                            if (size > 0) {
                                videoSizeMap.put(id, size);
                            }
                            if (mime != null && !mime.isEmpty()) {
                                videoMimeMap.put(id, mime);
                            }

                            // Clean title from filename if title is empty
                            if ((title == null || title.trim().isEmpty()) && data != null) {
                                String fileName = new File(data).getName();
                                int dotIndex = fileName.lastIndexOf('.');
                                title = dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
                            }

                            JSONObject obj = new JSONObject();
                            obj.put("id", "android-video-" + id);
                            obj.put("title", (title != null && !title.trim().isEmpty()) ? title : "Video Track");
                            obj.put("artist", (artist != null && !artist.equals("<unknown>") && !artist.trim().isEmpty()) ? artist : "Device Videos");
                            obj.put("album", (album != null && !album.equals("<unknown>") && !album.trim().isEmpty()) ? album : "Videos");
                            obj.put("duration", Math.max(1, (int)(durationMs / 1000)));
                            obj.put("audioUrl", "https://appassets.androidplatform.net/local-video/" + id);
                            obj.put("videoUrl", "https://appassets.androidplatform.net/local-video/" + id);
                            obj.put("filePath", data != null ? data : "");
                            obj.put("fileSize", String.format("%.1f MB", size / (1024.0 * 1024.0)));
                            String ext = "MP4";
                            if (data != null) {
                                int dotIdx = data.lastIndexOf('.');
                                if (dotIdx >= 0) {
                                    ext = data.substring(dotIdx + 1).toUpperCase();
                                }
                            }
                            obj.put("fileFormat", ext);
                            obj.put("hasMV", true);
                            obj.put("isVideoOnly", true);
                            obj.put("genre", "Local Video");
                            obj.put("isFavorite", false);
                            obj.put("playCount", 0);
                            obj.put("dateAdded", System.currentTimeMillis());
                            obj.put("folder", "Device Storage / Videos");
                            obj.put("artworkUrl", "https://appassets.androidplatform.net/local-video-thumb/" + id);

                            jsonArray.put(obj);
                        }
                        cursor.close();
                    }

                    final String payload = jsonArray.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            webView.evaluateJavascript("if (window.onAndroidLocalVideosScanned) { window.onAndroidLocalVideosScanned(" + payload + "); }", null);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private String getMimeType(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".mp3")) return "audio/mpeg";
        if (path.endsWith(".mp4")) return "video/mp4";
        if (path.endsWith(".mkv")) return "video/x-matroska";
        if (path.endsWith(".webm")) return "video/webm";
        return "application/octet-stream";
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean audioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
            boolean videoGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
            boolean imagesGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
            boolean notifGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;

            List<String> needed = new ArrayList<>();
            if (!audioGranted) needed.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (!videoGranted) needed.add(Manifest.permission.READ_MEDIA_VIDEO);
            if (!imagesGranted) needed.add(Manifest.permission.READ_MEDIA_IMAGES);
            if (!notifGranted) needed.add(Manifest.permission.POST_NOTIFICATIONS);

            if (!needed.isEmpty()) {
                ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            } else {
                scanLocalAudioFiles();
                scanLocalVideoFiles();
                registerMediaStoreObservers();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, PERMISSION_REQUEST_CODE);
            } else {
                scanLocalAudioFiles();
                scanLocalVideoFiles();
                registerMediaStoreObservers();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean anyGranted = false;
            for (int res : grantResults) {
                if (res == PackageManager.PERMISSION_GRANTED) {
                    anyGranted = true;
                    break;
                }
            }
            if (anyGranted) {
                scanLocalAudioFiles();
                scanLocalVideoFiles();
                registerMediaStoreObservers();
            }
        }
    }

    /**
     * Strict Hierarchical Back Press Navigation:
     * Dispatches back event to the Web UI stack first (WillPopScope / OnBackPressedDispatcher equivalent).
     * Only when at Level 0 (Home Songs tab with no modals/player active) does it
     * require a double-tap within 2000ms to minimize to background without stopping audio!
     */
    public void dispatchHierarchicalBackPress() {
        if (webView != null) {
            webView.evaluateJavascript(
                "(function() { return (window.handleAppBackPress ? window.handleAppBackPress() : false); })();",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if ("true".equalsIgnoreCase(value)) {
                            // Handled successfully by in-app navigation stack (modal, player, or tab)
                            return;
                        }

                        // At Level 0: Double-tap back confirmation
                        long currentTime = System.currentTimeMillis();
                        if (currentTime - lastBackPressTime < 2000) {
                            // Minimize to background so audio playback continues uninterrupted
                            moveTaskToBack(true);
                        } else {
                            lastBackPressTime = currentTime;
                            Toast.makeText(MainActivity.this, "Press back again to exit", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            );
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        dispatchHierarchicalBackPress();
    }
}
